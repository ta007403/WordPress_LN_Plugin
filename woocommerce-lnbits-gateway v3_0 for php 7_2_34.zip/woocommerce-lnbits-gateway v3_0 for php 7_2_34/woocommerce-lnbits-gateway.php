<?php
/**
 * Plugin Name: WooCommerce LNBits LN Invoice Gateway
 * Description: Accept Bitcoin Lightning payments via LNBits.
 * Version: 3.0
 * Author: Chanwut Norachan
 */

add_filter('woocommerce_payment_gateways', 'add_lnbits_ln_gateway');
function add_lnbits_ln_gateway($gateways) {
    $gateways[] = 'WC_Gateway_LNBits_LN';
    return $gateways;
}

add_action('plugins_loaded', 'init_lnbits_ln_gateway');
function init_lnbits_ln_gateway() {
    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_Gateway_LNBits_LN extends WC_Payment_Gateway {
        private $api_key;
        private $endpoint;
		private $consumer_key;
		private $secret_key;

        public function __construct() {
            $this->id = 'lnbits_ln_invoice';
            $this->has_fields = true;
            $this->method_title = 'Bitcoin Lightning (LNBits Invoice)';
            $this->method_description = 'Pay via BOLT11 Lightning invoice using LNBits';
            $this->title = 'Bitcoin Lightning (⚡ via LNBits)';

            $this->init_form_fields();
            $this->init_settings();

            $this->enabled = $this->get_option('enabled');
            $this->api_key = $this->get_option('api_key');
            $this->endpoint = $this->get_option('endpoint');
			
			$this->consumer_key = $this->get_option('consumer_key');
			$this->secret_key = $this->get_option('secret_key');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thank_you_page'));
        }
		
        public function payment_fields() {
            echo '<p>หลังจากกด "ยืนยันการสั่งซื้อ" ระบบจะแสดง QR Code สำหรับโอนเงินตามยอดรวมในตะกร้า ซึ่งเป็นการชำระเงินด้วย Bitcoin Lightning Network โดยที่เราไม่ต้องง้อธนาคารใดๆ</p>';
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable LNBits LN Invoice Payment',
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => 'Title',
                    'type' => 'text',
                    'default' => 'Bitcoin Lightning (⚡ via LNBits)'
                ),
                'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'default' => 'Pay with Lightning via LNBits'
                ),
                'api_key' => array(
                    'title' => 'LNBits Invoice/read key API Key',
                    'type' => 'password'
                ),
                'consumer_key' => array(
                    'title' => 'WooCommerce Consumer Key',
                    'type' => 'password'
                ),
                'secret_key' => array(
                    'title' => 'WooCommerce Secret Key',
                    'type' => 'password'
                ),
                'endpoint' => array(
                    'title' => 'LNBits API Endpoint',
                    'type' => 'text',
                    'default' => ''
                ),
                'redirect_url' => array(
                    'title' => 'Redirect URL After Payment',
                    'type' => 'text',
                    'description' => 'Full URL to redirect the customer after successful payment. Example: https://yourdomain.com/thank-you/'
                )
            );
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            $amount = $order->get_total();
            $sats = (int) round($amount * 100000000 / $this->get_btc_rate());

            $body = array(
                'out' => false,
                'amount' => $sats,
                'memo' => "Order #{$order_id} from WooCommerce",
                'webhook' => ''
            );

            $response = wp_remote_post("{$this->endpoint}/api/v1/payments", array(
                'method' => 'POST',
                'headers' => array(
                    'X-Api-Key' => $this->api_key,
                    'Content-Type' => 'application/json'
                ),
                'body' => json_encode($body),
                'timeout' => 30
            ));

            $body = json_decode(wp_remote_retrieve_body($response), true);
            error_log("📤 LNBits Invoice Response: " . print_r($body, true));

            if (empty($body['payment_request']) || empty($body['payment_hash'])) {
                wc_add_notice('LNBits did not return a valid invoice.', 'error');
                return;
            }

            update_post_meta($order_id, '_lnbits_payment_request', $body['payment_request']);
            update_post_meta($order_id, '_lnbits_payment_hash', $body['payment_hash']);

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_order_received_url()
            );
        }

        private function get_btc_rate() {
            $response = wp_remote_get('https://api.bitkub.com/api/market/ticker?sym=THB_BTC');
            if (is_wp_error($response)) return 1000000;
            $body = json_decode(wp_remote_retrieve_body($response), true);
            return $body['THB_BTC']['last'] ?? 1000000;
        }

		public function thank_you_page($order_id) {
			$payreq = get_post_meta($order_id, '_lnbits_payment_request', true);
			$hash = get_post_meta($order_id, '_lnbits_payment_hash', true);
			if (!$payreq || !$hash) return;

			$redirect_url = esc_url($this->get_option('redirect_url'));
			$consumer_key = esc_js($this->consumer_key);
			$secret_key = esc_js($this->secret_key);

			echo "<h2>⚡ Lightning Payment Invoice</h2>";
			echo "<p>Scan the QR code below to pay via Lightning:</p>";
			echo "<div id='qrcode'></div>";
			echo "<p><code style='word-wrap: break-word; display: block;'>{$payreq}</code></p>";
			echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js'></script>";

			echo '<script>
				new QRCode(document.getElementById("qrcode"), {
					text: "' . esc_js($payreq) . '",
					width: 256,
					height: 256
				});

				setInterval(function() {
					fetch("/?check_payment=' . $hash . '&order_id=' . $order_id . '")
					.then(response => response.json())
					.then(payment => {
						if (payment.paid === true) {
							fetch("/wp-json/wc/v3/orders/' . $order_id . '?consumer_key=' . $consumer_key . '&consumer_secret=' . $secret_key . '")
							.then(response => response.json())
							.then(data => {
								if (data.status === "completed") {
									window.location.href = "' . $redirect_url . '";
								}
							});
						}
					});
				}, 5000);
			</script>';
		}
    }
}

add_action('init', function () {
    if (isset($_GET['check_payment']) && isset($_GET['order_id'])) {
        $hash = sanitize_text_field($_GET['check_payment']);
        $order_id = absint($_GET['order_id']);
        $settings = get_option('woocommerce_lnbits_ln_invoice_settings');
        $api_key = $settings['api_key'];
        $endpoint = $settings['endpoint'];

        $response = wp_remote_get("{$endpoint}/api/v1/payments/{$hash}", array(
            'headers' => array('X-Api-Key' => $api_key)
        ));

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $paid = $body['paid'] ?? false;

		if ($paid && $order_id) {
			$order = wc_get_order($order_id);
			if ($order && $order->get_status() !== 'completed') {
				error_log("✅ Completing order #{$order_id} via polling...");
				$order->payment_complete();
				$order->update_status('completed', '✅ LNBits payment confirmed via polling.');
				$order->add_order_note('⚡️ LNBits invoice was paid. Order marked complete.');
			}
		}

        wp_send_json(array('paid' => $paid));
    }
});
